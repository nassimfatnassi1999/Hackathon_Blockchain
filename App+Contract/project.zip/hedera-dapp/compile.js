const solc = require('solc');
const fs = require('fs-extra');
const path = require('path');

// Define the contract path
const contractPath = path.resolve(__dirname, 'contracts', 'SimpleStorage.sol');
const source = fs.readFileSync(contractPath, 'utf8');

// Compile the contract
const input = {
    language: 'Solidity',
    sources: {
        'SimpleStorage.sol': {
            content: source,
        },
    },
    settings: {
        outputSelection: {
            '*': {
                '*': ['abi', 'evm.bytecode'],
            },
        },
    },
};

const output = JSON.parse(solc.compile(JSON.stringify(input)));

// Check for compilation errors
if (output.errors) {
    output.errors.forEach((err) => {
        console.error(err.formattedMessage);
    });
}

// Ensure the build directory exists
const buildPath = path.resolve(__dirname, 'build');
fs.ensureDirSync(buildPath);

// Write the compiled bytecode and ABI to the build directory
const contract = output.contracts['SimpleStorage.sol']['SimpleStorage'];
fs.writeFileSync(path.resolve(buildPath, 'SimpleStorage.bin'), contract.evm.bytecode.object);
fs.writeFileSync(path.resolve(buildPath, 'SimpleStorage.abi'), JSON.stringify(contract.abi));

console.log('Contract compiled and artifacts saved to build directory');
