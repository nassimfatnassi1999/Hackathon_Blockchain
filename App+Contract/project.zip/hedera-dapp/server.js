
console.clear();
const cors = require('cors');
const express = require('express');
require("dotenv").config();
const {
    AccountId,
	PrivateKey,
	Client,
	FileCreateTransaction,
	ContractCreateTransaction,
	ContractFunctionParameters,
	ContractExecuteTransaction,
	ContractCallQuery,
	Hbar,
	ContractCreateFlow,
} = require("@hashgraph/sdk");
const fs = require("fs");

// Configure accounts and client
const operatorId = AccountId.fromString(process.env.HEDERA_ACCOUNT_ID);
const operatorKey = PrivateKey.fromString(process.env.HEDERA_PRIVATE_KEY_HEX);

const app = express();
app.use(express.json());

app.use(cors({
    origin: 'http://localhost:3000', 
    methods: ['GET', 'POST'], 
    allowedHeaders: ['Content-Type'],
  }));

const client = Client.forTestnet().setOperator(operatorId, operatorKey);

let myContractId = "";

let myContractAddress = ""

const { main } = require('./deploy_aid_supplychain');


(async () => {
    try {
        const { contractId, contractAddress } = await main();

        

        console.log(`Contract ID: ${contractId}`);
        console.log(`Contract Address: ${contractAddress}`);

        myContractId = contractId;
        myContractAddress = contractAddress;
    } catch (error) {
        console.error('Error deploying contract:', error);
    }
})();


app.get('/health', (req, res) => {
    res.send('API is running');
});

app.post('/collect', async (req, res) => {
    const { quantity, description } = req.body;
    try {
        let num = parseInt(quantity);
        const contractExecuteTx = new ContractExecuteTransaction()
		   .setContractId(myContractId)
		   .setGas(300000)
	  	   .setFunction("collect", new ContractFunctionParameters()
            .addUint256(num)
            .addString(description));
	  const contractExecuteSubmit = await contractExecuteTx.execute(client);
	  const contractExecuteRx = await contractExecuteSubmit.getReceipt(client);
	   console.log(`- Contract function call status: ${contractExecuteRx.status} \n`);

       res.status(200).json({ status: 'success', contractStatus: contractExecuteRx.status.toString() });

    } catch (error) {
        res.status(500).json({ status: 'error', message: error.message });
    }
});

app.post('/announcement', async (req, res) => {
    const { quantity, description } = req.body;
    try {
        //let num = parseInt(quantity);
        const contractExecuteTx = new ContractExecuteTransaction()
		   .setContractId(myContractId)
		   .setGas(1000000)
	  	   .setFunction("create_announcement", new ContractFunctionParameters()
            .addUint256(quantity)
            .addString(description));
	  const contractExecuteSubmit = await contractExecuteTx.execute(client);
	  const contractExecuteRx = await contractExecuteSubmit.getReceipt(client);
	   console.log(`- Contract function call status: ${contractExecuteRx.status} \n`);

       console.log(`- Contract function call status: yes`);

       res.status(200).json({ status: 'success', contractStatus: contractExecuteRx.status.toString() });

    } catch (error) {
        res.status(500).json({ status: 'error', message: error.message });
    }
});

// Get Aid by ID function
app.get('/getAidById/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const contractCallQuery = new ContractCallQuery()
            .setContractId(myContractId)
            .setGas(300000)
            .setFunction("getAidById", new ContractFunctionParameters().addUint256(parseInt(id, 10)));

        const contractCallSubmit = await contractCallQuery.execute(client);

        const aidId = contractCallSubmit.getUint256(0);
        const quantity = contractCallSubmit.getUint256(1);
        const description = contractCallSubmit.getString(2);
        const region = contractCallSubmit.getString(3);
        const status = contractCallSubmit.getUint256(4);

        res.status(200).json({
            id_aid: aidId,
            quantity: quantity,
            description: description,
            region: region,
            status: status
        });
    } catch (error) {
        res.status(500).json({ status: 'error', message: error.message });
    }
});

// Get Announcements by ID function
app.get('/getAnnouncementsById/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const contractCallQuery = new ContractCallQuery()
            .setContractId(myContractId)
            .setGas(300000)
            .setFunction("getAnnouncementById", new ContractFunctionParameters().addUint256(parseInt(id, 10)));

        const contractCallSubmit = await contractCallQuery.execute(client);

        const id_announcement = contractCallSubmit.getUint256(0);
        const quantity = contractCallSubmit.getUint256(1);
        const description = contractCallSubmit.getString(2);

        res.status(200).json({
            id_announcement: id_announcement,
            quantity: quantity,
            description: description
        });
    } catch (error) {
        res.status(500).json({ status: 'error', message: error.message });
    }
});

// Get getAllAid

app.get('/getAllAid', async (req, res) => {
    try {
        const contractCallQuery = new ContractCallQuery()
            .setContractId(myContractId)
            .setGas(300000)
            .setFunction("getAllAid", new ContractFunctionParameters());

        const contractCallSubmit = await contractCallQuery.execute(client);

        const result = contractCallSubmit.getUint256(0); // Assuming the array of aids is returned as a single array
        const aids = [];

        for (let i = 0; i < result.length; i++) {
            const aidId = result[i];
            const quantity = contractCallSubmit.getUint256(i * 5 + 1);
            const description = contractCallSubmit.getString(i * 5 + 2);
            const region = contractCallSubmit.getString(i * 5 + 3);
            const status = contractCallSubmit.getUint8(i * 5 + 4);

            aids.push({
                id_aid: aidId,
                quantity: quantity,
                description: description,
                region: region,
                status: status
            });
        }
        console.log(aids)
        res.status(200).json(aids);
    } catch (error) {
        res.status(500).json({ status: 'error', message: error.message });
    }
});



const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});