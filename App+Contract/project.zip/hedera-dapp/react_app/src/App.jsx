import React from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from './pages/Home'; // Your Home component
import FormAidAdd from './pages/FormAidAdd'; // Your Add Aid component
import FormAnnouncements from './pages/FormAnnouncements'; // Your Add Aid component
//import AllAids from './AllAids'; // Your All Aids component
//import AllAids from './AllAids'; // Your All Aids component

const App = () => {
  return (

     <>
       <BrowserRouter>
           <Routes>
              <Route path="/">
                <Route index element={<Home/>} />
                <Route path="add-aid" element={<FormAidAdd/>}/>
                <Route path="add-announcements" element={<FormAnnouncements/>}/>
              </Route>     
            </Routes>
        </BrowserRouter>
     </>
      
  );
};

export default App;

