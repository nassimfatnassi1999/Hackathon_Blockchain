import React from 'react';
import { NavLink } from 'react-router-dom';
import './Navbar.css'; // Import the CSS file

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <NavLink to="/" className="nav-link" activeClassName="active-link" exact>Home</NavLink>
        <NavLink to="/add-aid" className="nav-link" activeClassName="active-link">Add Aid</NavLink>
        <NavLink to="/add-announcements" className="nav-link" activeClassName="active-link">Add Announcements</NavLink>     
      </div>
    </nav>
  );
};

export default Navbar;
