import React from 'react';
import Navbar from './Navbar'; // Import the Navbar component

const Home = () => {
  return (
    <>
     <Navbar />
      <div >
          home
      </div>
    </>
  );
};

export default Home;
