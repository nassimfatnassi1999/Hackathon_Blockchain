import React, { useState } from 'react';
import { useFormik } from 'formik';
import { queryApi } from "../utils/queryApi";
import './Form.css';
import Navbar from './Navbar'; // Import the Navbar component
//import * as Yup from 'yup';

const FormAnnouncements = () => {
  const [error, setError] = useState({ visible: false, message: '' });
  const formik = useFormik({
    initialValues: {
      quantity: '',
      description: '',
    },
    //validationSchema: yupSchema,
    onSubmit: async (values) => {
      try {
           console.log(values);
           const [announcement, err] = await queryApi("announcement", values, "POST", false);  
           console.log(announcement)
        
        if (!announcement) {
          console.log("errrrooooooooooooooooooooor")
          setError({
            visible: true,
            message: JSON.stringify(err.errors, null, 2),
          });
        } else { 

          console.log(announcement)
          //window.location = "/home";
       };
        
      } catch (error) {
        setError({ visible: true, message: 'An error occurred during the add of announcement.' });
      }
    },
  });

  return (
    <> 
    <Navbar />
       <div className="form-container">
    <form onSubmit={formik.handleSubmit}>
      <div className="form-group">
        <label htmlFor="quantity">Quantity:</label>
        <input
          type="text"
          id="quantity"
          name="quantity"
          value={formik.values.quantity}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
        />
      </div>
      <div className="form-group">
        <label htmlFor="description">Description:</label>
        <input
          type="text"
          id="description"
          name="description"
          value={formik.values.description}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
        />
      </div>
      <button type="submit">Submit</button>
    </form>
  </div>
    </>
    
  );
};

// const yupSchema = Yup.object({
//   email: Yup.string().required('Champs requis!'),
//   password: Yup.string().required('Champs requis!'),
// });


export default FormAnnouncements;
