//console.clear();
require("dotenv").config();
const {
    AccountId,
	PrivateKey,
	Client,
	FileCreateTransaction,
	ContractCreateTransaction,
	ContractFunctionParameters,
	ContractExecuteTransaction,
	ContractCallQuery,
	Hbar,
	ContractCreateFlow,
} = require("@hashgraph/sdk");
const fs = require("fs");


// Configure accounts and client
const operatorId = AccountId.fromString(process.env.HEDERA_ACCOUNT_ID);
const operatorKey = PrivateKey.fromString(process.env.HEDERA_PRIVATE_KEY_HEX);

const client = Client.forTestnet().setOperator(operatorId, operatorKey);

async function main() {
// Import the compiled contract bytecode
const contractBytecode = fs.readFileSync("./build/AidSupplyChain.bin");

// Instantiate the smart contract
const contractInstantiateTx = new ContractCreateFlow()
.setBytecode(contractBytecode)
.setGas(200000)
.setConstructorParameters(new ContractFunctionParameters());
const contractInstantiateSubmit = await contractInstantiateTx.execute(client);
const contractInstantiateRx = await contractInstantiateSubmit.getReceipt(client);
const contractId = contractInstantiateRx.contractId;
const contractAddress = contractId.toSolidityAddress();
console.log(`- The smart contract ID is: ${contractId} \n`);
console.log(`- The smart contract ID in Solidity format is: ${contractAddress} \n`);

	//function collect(uint256 _quantity, string memory _description)

	const contractExecuteTx = new ContractExecuteTransaction()
		.setContractId(contractId)
		.setGas(300000)
		.setFunction("collect", new ContractFunctionParameters().addUint256(100).addString("first aid from someone"));
	const contractExecuteSubmit = await contractExecuteTx.execute(client);
	const contractExecuteRx = await contractExecuteSubmit.getReceipt(client);
	console.log(`- Contract function call status: ${contractExecuteRx.status} \n`);

	// const contractAddSecondAidExecuteTx = new ContractExecuteTransaction()
	// 	.setContractId(contractId)
	// 	.setGas(100000)
	// 	.setFunction("collect", new ContractFunctionParameters().addUint256(50).addString("second aid from someone"));
	// const contractsExecuteAddSecondAidSubmit = await contractAddSecondAidExecuteTx.execute(client);
	// const contractExecuteRxAddSecondAid = await contractsExecuteAddSecondAidSubmit.getReceipt(client);
	// console.log(`- Contract function call status: ${contractExecuteRxAddSecondAid.status} \n`);

	// const contractAddthirdAidExecuteTx = new ContractExecuteTransaction()
	// 	.setContractId(contractId)
	// 	.setGas(100000)
	// 	.setFunction("collect", new ContractFunctionParameters().addUint256(14).addString("third aid from someone RRR"));
	// const contractsExecuteAddthirdAidSubmit = await contractAddthirdAidExecuteTx.execute(client);
	// const contractExecuteRxAddthirdAid = await contractsExecuteAddthirdAidSubmit.getReceipt(client);
	// console.log(`- Contract function call status: ${contractExecuteRxAddthirdAid.status} \n`);

	// Query the contract to check changes in state variable
	// const contractQueryTx1 = new ContractCallQuery()
	// 	.setContractId(contractId)
	// 	.setGas(100000)
	// 	.setFunction("getAidById", new ContractFunctionParameters().addUint256(1));
	// const contractQuerySubmit1 = await contractQueryTx1.execute(client);
	// const contractQueryResult1 = contractQuerySubmit1.getUint256(0);
    // const quantity = contractQuerySubmit1.getUint256(1);
    // const description = contractQuerySubmit1.getString(2);
    // const region = contractQuerySubmit1.getString(3);
    // const status = contractQuerySubmit1.getUint256(4);
	// console.log(`- Here's the aid that you asked for: 
    // ID: ${contractQueryResult1},
    // Quantity: ${quantity},
    // Description: ${description},
    // Region: ${region},
    // Status: ${status}\n`);

	// // Query the contract to check changes in state variable
	// const contractQueryTx2 = new ContractCallQuery()
	// 	.setContractId(contractId)
	// 	.setGas(100000)
	// 	.setFunction("getAidById", new ContractFunctionParameters().addUint256(2));
	// const contractQuerySubmit2 = await contractQueryTx2.execute(client);
	// const contractQueryResult2 = contractQuerySubmit2.getUint256(0);
    // const quantity2 = contractQuerySubmit2.getUint256(1);
    // const description2 = contractQuerySubmit2.getString(2);
    // const region2 = contractQuerySubmit2.getString(3);
    // const status2 = contractQuerySubmit2.getUint256(4);
	// console.log(`- Here's the aid that you asked for: 
    // ID: ${contractQueryResult2},
    // Quantity: ${quantity2},
    // Description: ${description2},
    // Region: ${region2},
    // Status: ${status2}\n`);

	// // Query the contract to check changes in state variable
	// const contractQueryTx3 = new ContractCallQuery()
	// 	.setContractId(contractId)
	// 	.setGas(100000)
	// 	.setFunction("getAidById", new ContractFunctionParameters().addUint256(3));
	// const contractQuerySubmit3 = await contractQueryTx3.execute(client);
	// const contractQueryResult3 = contractQuerySubmit3.getUint256(0);
    // const quantity3 = contractQuerySubmit3.getUint256(1);
    // const description3 = contractQuerySubmit3.getString(2);
    // const region3 = contractQuerySubmit3.getString(3);
    // const status3 = contractQuerySubmit3.getUint256(4);
	// console.log(`- Here's the aid that you asked for: 
    // ID: ${contractQueryResult3},
    // Quantity: ${quantity3},
    // Description: ${description3},
    // Region: ${region3},
    // Status: ${status3}\n`);
	return { contractId: contractId.toString(), contractAddress };

}
     

module.exports = { main };


